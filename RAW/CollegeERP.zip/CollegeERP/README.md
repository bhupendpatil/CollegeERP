# College Management System Project

Made project in Visual Studio 2017

Language used is C# with .Net

For database used Microsoft Server 2017

So to run project in your PC you'll neeed Visual Studio 2017 and Microsoft Server 2017

Anyone can use this project (under GNU GENERAL PUBLIC LICENSE)



(mail me thankyou if you want to)

Email ID : bhupendpatil@gmail.com